import React from 'react';

function Pokemon(props){
    return(
      <div>
        <div>
          {props.game.map((data,index)=>(
              <React.Fragment key={index}>
          <div>
             <img
             src="https://i.imgur.com/2aWw56B.jpg"
             title="pokemon img"
             />
             <br/>
            <div>
              <span className="name"><strong>{data.name}</strong></span>
            </div>
            <br/>            
            <div>
              <strong>CP </strong>
              <span aria-label="CP">
                  {data.CP}
              </span>
            </div>
            <div>
              <strong>HP </strong>
              <span aria-label="Health">
                {data.HP}
              </span>
            </div>
            <div>
              <strong>Defense </strong>              
              <span aria-label="Defense">
                {data.Defense}
              </span>
            </div>
            <div>
              <strong>Attack </strong>
              <span aria-label="Attack">
                {data.Attack}
              </span>
            </div>
            <div>
              <strong>Type1 </strong>
              <span aria-label="Type1">
                {data.type1}
              </span>
            </div>
            <div>
              <strong>Type2 </strong>
              <span aria-label="Type2">
                {data.type2}
              </span>
            </div>
        </div>
        <hr/>        
        </React.Fragment>
        ))}
    </div>
  </div>
    )
}
export default Pokemon;
