import React from 'react';
import pokemonData from './PokemonData.js';
import Pagination from './Pagination.jsx';
import Pokemon from './Pokemon.jsx';
import Header from '../common/Header.jsx';

 class List extends React.Component {
  constructor(){
    super(); // have to call it because it is a subclass of Component also this is uninitialized if super is not called
    this.state={
      game:[],
      page:1,
      totalPages:0,
      updatedData:[],
      error:null,
      filterData:[],
    }
    this.Pagination=this.Pagination.bind(this);
    this.filterList = this.filterList.bind(this);
    this.handlePaginationClick=this.handlePaginationClick.bind(this)
  }

  componentDidMount(){
    console.log(pokemonData)
    this.setState({game:pokemonData,totalPages:pokemonData.length/10},()=>this.Pagination(0,10));
  }

  filterList(event) {
    let updated = this.state.filterData.filter(game =>
      game.name.toLowerCase().includes(event.target.value)
    );
    this.setState({
      updatedData: updated
    });
  }

  handlePaginationClick(direction) {
    let numberOfItems=10
    let nextPage = this.state.page;

    // Increment nextPage if direction variable is next, otherwise decrement
    nextPage = direction === 'next' ? nextPage + 1 : nextPage - 1;

    this.setState({ page: nextPage }, () => {
      
      // because we have to make sure first page state is updated
      if(direction==='next'){
      this.Pagination(nextPage*numberOfItems,(nextPage*numberOfItems+numberOfItems))
    }
    else{
      this.Pagination(nextPage*numberOfItems-numberOfItems,(nextPage*numberOfItems))
    }
    });
  }

  Pagination(start,end){
    let arr=[];
    for(let i=start;i<end;i++){
      arr.push(this.state.game[i])      
    }
    console.log(arr)
    this.setState({updatedData:arr,filterData:arr})
  }
  render() {

  const{error,game,page,totalPages,updatedData}=this.state
    if(error){
      return <div className="error">{error}</div>
    }
    return (<div>
          <Header/>
          <input
            id="search"
            type="text"
            label="Search"
            placeholder="Search"
            onChange={this.filterList}
          />
        <Pokemon game={updatedData}/>
        <Pagination
          page={page}
          totalPages={totalPages}
          handlePaginationClick={this.handlePaginationClick}
        />
    </div>)
  }
}

export default List;
