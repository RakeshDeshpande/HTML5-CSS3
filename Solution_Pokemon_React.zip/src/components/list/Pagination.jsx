import React from 'react';
// import './Pagination.css';

const Pagination = (props) => {
  const { page, totalPages, handlePaginationClick } = props;

  return (
    <div className="Pagination">
      <button
        className="Pagination-button" id="previous"
        onClick={() => handlePaginationClick('prev')}
        disabled={page <= 1}
      >
        &larr;
      </button>

      <span className="Pagination-info" >
        <span id="pagination">page <strong>{page}</strong> of <strong>{totalPages}</strong></span>
      </span>

      <button
        className="Pagination-button" id="next"
        onClick={() => handlePaginationClick('next')}
        disabled={page >= totalPages}
      >
        &rarr;
      </button>
    </div>
  );
}

export default Pagination;
