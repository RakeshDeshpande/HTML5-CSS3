import React from 'react';

const Header=(props)=>{
  return(
    <div>Pokemon Search</div>
  )
}

export default Header;
